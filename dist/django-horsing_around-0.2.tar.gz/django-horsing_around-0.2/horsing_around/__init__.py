import logging
from .enums import City, PageType, ManagerType

logger = logging.getLogger(__name__)