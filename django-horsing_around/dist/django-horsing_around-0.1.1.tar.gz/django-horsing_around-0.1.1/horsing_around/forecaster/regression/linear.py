# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


class Regression:
    def __init__(self, fixture):
        """
        :param fixture: List contains races which contains Fixture model
        """
        self.fixture = fixture


    def get_X_y(self, horse_results):
        """

        :param horse:
        :return:
        """
    def forecast(self):
        return self.fixture.time_as_seconds()

#regressor = LinearRegression()
#regressor.fit(X_train, y_train)

# Predict
#y_pred = regressor.predict(X_test)