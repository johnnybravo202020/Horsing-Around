from django.test import TestCase
from ..models import FixtureTestData, RaceDayTestData, HorseTestData
from .scrapper import FixtureScrapper, City, HorseScrapper
import datetime


class RegressionTestCase(TestCase):
    def test_can_do_linear_regression(self):
        #  scrapper = FixtureScrapper(City.Ankara, datetime.datetime(2017, 10, 28), get_past_statistics=True)
        # races = scrapper.get()
        # for race in races:
        #     for result in race:
        #         for p_result in result.past_results:
        #             print(result)
        #             past_result = HorseTestData.from_actual(p_result, '-1')
        #             raise Exception(past_result)
        #             past_result.save()

        sc = HorseScrapper(75046)

        results = sc.get()
        for i, res in enumerate(results):
            test_data = HorseTestData.from_actual(res, sc.rows[i])
            a = test_data.saveasd()
            raise Exception(a)
