from django.apps import AppConfig


class HorsingAroundConfig(AppConfig):
    name = 'horsing_around'
