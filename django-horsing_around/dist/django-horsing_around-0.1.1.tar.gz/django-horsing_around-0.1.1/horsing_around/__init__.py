import logging
from .enum import City, PageType

logger = logging.getLogger(__name__)